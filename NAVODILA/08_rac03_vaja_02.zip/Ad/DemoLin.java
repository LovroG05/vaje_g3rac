/**
 *    +++++++      +
 *          +      +
 *          +      +
 *          ++++++++
 */
public class DemoLin{  
    public static void main(String[] args){
      Linije.desno(6,'+');
      Linije.dol(4,'+');
      Linije.desno(6,'+');
      Linije.gor(4,'+');   
    }
}
