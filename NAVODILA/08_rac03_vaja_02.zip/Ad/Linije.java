class Linije{
    
    private static int xPos = 0;   // pozicija v ravnini
    private static int yPos = 0;
        
    public static void gor(int koliko, char kaj){}
    public static void dol(int koliko, char kaj){}
    public static void levo(int koliko, char kaj){}
    public static void desno(int koliko, char kaj){}
}



