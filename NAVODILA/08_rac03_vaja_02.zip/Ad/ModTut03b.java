import com.googlecode.lanterna.*;
import com.googlecode.lanterna.graphics.TextGraphics;
import com.googlecode.lanterna.screen.Screen;
import com.googlecode.lanterna.screen.TerminalScreen;
import com.googlecode.lanterna.terminal.DefaultTerminalFactory;
import com.googlecode.lanterna.terminal.Terminal;

import java.io.IOException;
import java.util.Random;

/**
 * 
 */
public class ModTut03b {
    public static void main(String[] args) {
        
        try {
            //Terminal terminal = new DefaultTerminalFactory(System.out, System.in, Charset.forName("UTF8")).createTerminal();
            Terminal terminal = new DefaultTerminalFactory().createTerminal();
            
            terminal.enterPrivateMode();

            terminal.setCursorPosition(10, 5);
            terminal.putCharacter('H');
            terminal.putCharacter('e'); 
            terminal.setCursorPosition(0, 0);
           
            terminal.flush();
            
            //------------ sleep za cca 3s            
            try {
                    Thread.sleep(3000);
                }
                catch(InterruptedException ignore) {
                   
                }
                
            // --------------- dol    
                
            int lastX=0; terminal.setCursorPosition(5,lastX);
            int i=lastX;
            for (;i<10;i++) {
               terminal.setCursorPosition(5, i);
               terminal.setForegroundColor​(TextColor.ANSI.DEFAULT);
               terminal.putString("**********");
               terminal.setCursorPosition(5, i+1);
               terminal.setForegroundColor​(TextColor.ANSI.RED);
               terminal.putString("**********");
               terminal.flush();
               
               
              try {
                    Thread.sleep(500);
                }
                catch(InterruptedException ignore) {
                   
                }
               
               
            }
            
            //--------------gor
            
            for (;i>=0;i--) {
               terminal.setCursorPosition(5, i);
               terminal.setForegroundColor​(TextColor.ANSI.DEFAULT);
               terminal.putString("**********");
               terminal.setCursorPosition(5, i-1);
               terminal.setForegroundColor​(TextColor.ANSI.RED);
               terminal.putString("**********");
               terminal.flush();
               
               
              try {
                    Thread.sleep(500);
                }
                catch(InterruptedException ignore) {
                   
                }
               
               
            }
            
           
            //terminal.exitPrivateMode();
        }
        catch (IOException ioe) {
            ioe.printStackTrace();
        }       
    }
}