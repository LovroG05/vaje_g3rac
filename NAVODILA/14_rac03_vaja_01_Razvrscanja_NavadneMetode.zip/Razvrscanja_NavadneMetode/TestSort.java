
/**
 * class NavadnoVstavljanje here.
 * 
 * @author G3ab
 * @version feb2013
 */
import java.util.Arrays;
import sortiranja.*;

public class TestSort
{
    static int tab[]={3,1,5,7,4,9,8,6,2,0};

    


    public static void main(String[] s){
        /*
        // navadno vstavljanje
        System.out.println(Arrays.toString(tab));
        Sortiraj.navadnoVstavljanje(tab);
        System.out.println(Arrays.toString(tab));
        */
        // navadno izbiranje
        System.out.println(Arrays.toString(tab));
        Sortiraj.navadnoIzbiranje(tab);
        System.out.println(Arrays.toString(tab));
        
    }    
}
