
/**
 * Write a description of class TestCircQueue here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class TestCircQueue{
    
    public static void main(String[] args){
    
        
        CircularQueue.pokaziVrsto();
        CircularQueue.dodaj(17);
        CircularQueue.pokaziVrsto();
        CircularQueue.dodaj(5); CircularQueue.dodaj(11);CircularQueue.dodaj(6);
        CircularQueue.pokaziVrsto();
        int elelent = CircularQueue.odvzemi();
        CircularQueue.pokaziVrsto();
    }
    
}
