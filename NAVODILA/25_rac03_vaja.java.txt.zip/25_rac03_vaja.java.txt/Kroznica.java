import java.awt.Color;

class Kroznica extends Lik {
   double radij; 

   public Kroznica(int x, int y, double radij){
       super(x,y);
       this.radij=radij;
   }
   
   public String toString(){
       return super.toString().substring(0,super.toString().length()-1)+",r:"+radij+")";
   }
}

