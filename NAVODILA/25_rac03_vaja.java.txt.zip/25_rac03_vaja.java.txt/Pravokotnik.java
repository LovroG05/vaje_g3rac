
class Pravokotnik extends Kvadrat {
   double stranicaB;
   public Pravokotnik(int x, int y, double stranicaA, double stranicaB){
      super(x,y,stranicaA);
      this.stranicaB=stranicaB;
   }
   
    public String toString(){
       return super.toString().substring(0,super.toString().length()-1)+","+stranicaB+")";
   }
}